-------------------------------------------------------------------------------
                               Gemalto M2M GmbH
                Driver package for ALSx PLSx LTE Module series
-------------------------------------------------------------------------------

Installation:
-------------
The installation is done via the Windows device manager. If there are older
drivers installed the modem and virtual COM port driver installation can be
executed as an update installation.
If there is an older NDIS 5.1 network driver installed it is not possible to
replace it with a simple update installation. To install the new NDIS 6.2
driver the old network driver must be uninstalled completely (select
"Uninstall" with enabling "Delete the driver software for this device" via the
Windows device manager) before an installation of the new driver is possible.
Note: If the used module and PC are supporting USB2.x and USB3.x, the above
installation might need to be repeated for both enumerations.

Compatibility:
--------------
The network driver is supporting the NDIS 6.2 interface which has been
introduced with Windows 7. This means that it is not working anymore on Windows
versions prior to Windows 7.
The network interfaces are configured, connected and disconnected via the
network icon in the Windows system tray. The ConnectionManager responsible for
these tasks with the old NDIS 5.1 driver has become obsolete and is not
delivered anymore.

Known Issues:
-------------
Windows saves the network adapter specific settings based on the IMSI of the
SIM card. Because the Gemalto ALSx PLSx LTE module series provide 2 independent
network interfaces running on the same SIM card the NDIS driver needs to patch
the last digit of the IMSI reported by the used module to allow specific
settings for each network interface. So the IMSI reported by Windows in the
network adapter settings is not the exact IMSI of the used SIM card.

-------------------------------------------------------------------------------
Berlin, Germany                                           8th of September 2015
-------------------------------------------------------------------------------
